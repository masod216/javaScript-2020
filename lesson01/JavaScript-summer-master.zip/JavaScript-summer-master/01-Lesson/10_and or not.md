# AND

1 && 1 = 1
1 && 0 = 0
0 && 1 = 0
0 && 0 = 0

true && true = true

# OR

1 || 1 = 1
1 || 0 = 1
0 || 1 = 1
0 || 0 = 0

# NOT

!1 = 0
!0 = 1

!true = false
!false = true